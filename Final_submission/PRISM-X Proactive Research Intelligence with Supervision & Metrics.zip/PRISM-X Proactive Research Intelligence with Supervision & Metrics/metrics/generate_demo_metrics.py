# metrics/generate_demo_metrics.py
import json
import random
from datetime import datetime

# Simulated NOVA-only results (no AEGIS filtering)
nova_only = [
    {"idea": "Behavioral Alzheimer Detection via Smartwatch Data", "relevance_score": round(random.uniform(6, 9), 2), "novelty_score": round(random.uniform(4, 7), 2), "safety_flag": random.choice([False, False, True])},
    {"idea": "AI Model for Disease Spread Simulation", "relevance_score": 5.5, "novelty_score": 6.1, "safety_flag": False},
    {"idea": "Copy of NeurIPS 2022 Paper on AD Progression", "relevance_score": 7.8, "novelty_score": 3.5, "safety_flag": True},
    {"idea": "Genomic Pattern Detection in Neurological Decline", "relevance_score": 6.9, "novelty_score": 6.0, "safety_flag": False}
]

# Simulated NOVA + AEGIS results (after filtering)
aegis_filtered = [
    idea for idea in nova_only if not idea["safety_flag"] and idea["novelty_score"] >= 5.5
]

# Write both sets to JSON
with open("metrics/nova_only.json", "w") as f1:
    json.dump(nova_only, f1, indent=2)

with open("metrics/aegis_filtered.json", "w") as f2:
    json.dump(aegis_filtered, f2, indent=2)

print("✅ Demo metric data written: nova_only.json and aegis_filtered.json")