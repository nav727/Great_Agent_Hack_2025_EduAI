# run_demo.py
from dotenv import load_dotenv
load_dotenv()

import os
from aegis.aegis_wrapper import AegisWrapper
from nova.arxiv_scraper import ArxivScraper
from nova.idea_generator import IdeaGenerator
from nova.citation_ranker import CitationRanker

# -------- CONFIG --------
TOPIC = "disease prediction for Alzheimer's"
BUZZWORDS = ["AI", "Alzheimer's", "prediction", "early detection", "machine learning"]
MAX_PAPERS = 5
RELEVANCE_THRESHOLD = 6.5  # Only include papers rated >= 6.5
# ------------------------

print(f"\n🎯 Starting NOVA + AEGIS pipeline for topic: {TOPIC}")
aegis = AegisWrapper(valyu_api_key=os.getenv("VALYU_API_KEY")) 
scraper = ArxivScraper()
ranker = CitationRanker()
generator = IdeaGenerator()

# 1. Scrape papers
papers = scraper.fetch(TOPIC, max_results=MAX_PAPERS)
if not papers:
    print("❌ No relevant papers found for the given topic.")
    exit()

# 2. Rank papers by relevance
ranked = ranker.rank(BUZZWORDS, papers)
filtered = [p for p in ranked if p["relevance_score"] >= RELEVANCE_THRESHOLD]

if not filtered:
    print("❌ No papers met the relevance threshold.")
    exit()

# 3. Summarize top papers
summaries = [p.get("summary", "") for p in filtered[:3]]

# 4. Generate research ideas
ideas = generator.generate(summaries, BUZZWORDS)
if not ideas:
    print("⚠️ No ideas were generated.")
    exit()

# 5. Load into AEGIS and run evaluations
aegis.bootstrap_knowledge(topic=TOPIC)
print("\n✅ Evaluating ideas...\n")
for i, idea in enumerate(ideas, 1):
    result = aegis.check_idea(idea)
    print(f"{i}. {idea.get('name', 'Unnamed')}: {result['decision']} ({result['reason']})")

# 6. Simulate an adversarial attack
print("\n⚔️ Red-team attack in progress...")
atk_result = aegis.run_attack(use_research=True)
print(f"Result: {atk_result['guardian']['decision']} | Reason: {atk_result['guardian']['reason']}")

print("\n📁 Check 'logs/aegis_log.jsonl' for full traces.\n")
