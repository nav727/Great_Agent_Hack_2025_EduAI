from holistic_ai_bedrock import get_chat_model
from dotenv import load_dotenv
load_dotenv()

llm = get_chat_model("claude-3-sonnet")
response = llm.invoke("Hello, what is agent governance?")
print("\n✅ Claude says:", response.content)
