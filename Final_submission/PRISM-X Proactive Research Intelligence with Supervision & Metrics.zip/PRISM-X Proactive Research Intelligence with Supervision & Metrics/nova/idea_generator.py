from holistic_ai_bedrock import get_chat_model
from datetime import datetime
from typing import List, Dict

class IdeaGenerator:
    def __init__(self):
        self.llm = get_chat_model()

    def generate(self, summaries: List[str], buzzwords: List[str]) -> List[Dict]:
        prompt = """
You are a research assistant. Based on the following research summaries and buzzwords, generate 3 original research ideas.
Include:
- NAME
- DOMAIN
- RESEARCH_GAP
- WHY_NOVEL
- METHOD_SKETCH

Summaries:
""" + "\n\n".join(summaries[:3]) + """

Buzzwords: """ + ", ".join(buzzwords) + """

Format:
---
IDEA 1
NAME: <...>
DOMAIN: <...>
RESEARCH_GAP: <...>
WHY_NOVEL: <...>
METHOD_SKETCH: <...>
---
"""
        result = self.llm.invoke(prompt)
        ideas = []
        for chunk in result.content.split('---'):
            if 'NAME:' in chunk:
                entry = {'raw': chunk.strip(), 'timestamp': datetime.now().isoformat()}
                for line in chunk.strip().splitlines():
                    if ':' in line:
                        k, v = line.split(':', 1)
                        entry[k.strip().lower()] = v.strip()
                if 'name' in entry:
                    ideas.append(entry)
        return ideas