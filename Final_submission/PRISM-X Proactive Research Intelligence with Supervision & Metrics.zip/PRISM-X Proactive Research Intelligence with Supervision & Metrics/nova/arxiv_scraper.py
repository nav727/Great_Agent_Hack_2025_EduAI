import requests
from datetime import datetime
import xml.etree.ElementTree as ET
from typing import List, Dict

class ArxivScraper:
    def __init__(self):
        self.api_url = "http://export.arxiv.org/api/query"

    def fetch(self, topic: str, max_results: int = 5) -> List[Dict]:
        params = {
            'search_query': f"all:{topic}",
            'start': 0,
            'max_results': max_results,
            'sortBy': 'relevance',
            'sortOrder': 'descending'
        }
        try:
            response = requests.get(self.api_url, params=params, timeout=30)
            response.raise_for_status()
        except Exception as e:
            print(f"❌ Error fetching ArXiv papers: {e}")
            return []

        root = ET.fromstring(response.content)
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        entries = root.findall('atom:entry', ns)
        papers = []
        for entry in entries:
            title = entry.find('atom:title', ns).text.strip()
            summary = entry.find('atom:summary', ns).text.strip()
            link = entry.find('atom:id', ns).text.strip()
            authors = ", ".join([a.find('atom:name', ns).text for a in entry.findall('atom:author', ns)])
            papers.append({
                'title': title,
                'abstract': summary,
                'url': link,
                'authors': authors,
                'published': entry.find('atom:published', ns).text,
                'source': 'arxiv',
                'scraped_at': datetime.utcnow().isoformat()
            })
        return papers
