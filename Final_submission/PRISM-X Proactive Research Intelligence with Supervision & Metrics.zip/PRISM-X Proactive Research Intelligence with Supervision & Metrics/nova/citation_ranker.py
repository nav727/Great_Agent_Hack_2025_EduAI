from holistic_ai_bedrock import get_chat_model
from typing import List, Dict

class CitationRanker:
    def __init__(self):
        self.llm = get_chat_model()

    def rank(self, buzzwords: List[str], papers: List[Dict]) -> List[Dict]:
        ranked = []
        for paper in papers:
            prompt = f"""
Buzzwords: {', '.join(buzzwords)}

Evaluate the relevance of this paper (1 to 10):
Title: {paper['title']}
Abstract: {paper['abstract']}

Respond with just a number."""
            score = self.llm.invoke(prompt).content.strip()
            try:
                paper['relevance_score'] = float(score)
            except:
                paper['relevance_score'] = 5.0
            ranked.append(paper)
        return sorted(ranked, key=lambda x: -x['relevance_score'])