from langchain_valyu import ValyuSearchTool
from typing import List

class ValyuResearchFetcher:
    def __init__(self, valyu_api_key: str):
        self.search_tool = ValyuSearchTool(
            valyu_api_key=valyu_api_key,
            search_type="academic",
            max_num_results=10,
            relevance_threshold=0.4
        )

    def fetch_related_snippets(self, query: str) -> List[str]:
        print(f"📡 Querying Valyu for: {query}")
        try:
            response = self.search_tool._run(query=query)
        except Exception as e:
            print(f"❌ Valyu error: {e}")
            return []

        snippets = []
        if hasattr(response, 'results'):
            for result in response.results:
                content = result.dict().get('snippet', '')[:300]
                if content:
                    snippets.append(content)
        return snippets