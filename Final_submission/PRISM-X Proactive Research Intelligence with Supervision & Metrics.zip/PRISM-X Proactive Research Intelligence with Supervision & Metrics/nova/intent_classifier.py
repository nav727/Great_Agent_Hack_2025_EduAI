from holistic_ai_bedrock import get_chat_model
from datetime import datetime
from typing import Dict, Any

class IntentClassifier:
    def __init__(self):
        self.llm = get_chat_model()

    def classify(self, user_input: str) -> Dict:
        prompt = f"""Analyze the following input:
Input: \"{user_input}\"

Classify as:
INTENT: [IDEA_GENERATION | QUESTION | MISUSE | JAILBREAK | UNCLEAR]
RISK_LEVEL: [LOW | MEDIUM | HIGH]
REASONING: [short reason]"""
        response = self.llm.invoke(prompt)
        lines = response.content.strip().splitlines()
        result: Dict[str, Any] = {'input': user_input, 'timestamp': datetime.now().isoformat()}
        for line in lines:
            if ':' in line:
                key, value = line.split(':', 1)
                result[key.strip().lower()] = value.strip()
        result.setdefault('intent', 'UNCLEAR')
        result.setdefault('risk_level', 'MEDIUM')
        return result