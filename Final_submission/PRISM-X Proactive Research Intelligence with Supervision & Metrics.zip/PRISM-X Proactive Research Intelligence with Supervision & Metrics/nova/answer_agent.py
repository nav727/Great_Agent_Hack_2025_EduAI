from holistic_ai_bedrock import get_chat_model

class AnswerAgent:
    def __init__(self):
        self.llm = get_chat_model()

    def answer(self, user_input: str, subject: str = "general") -> str:
        prompt = f"""You are an AI tutor helping a student learn.
STUDENT QUESTION: \"{user_input}\"
SUBJECT: {subject}

Provide a helpful educational response that:
1. Teaches relevant concepts rather than giving a direct answer.
2. Asks a guiding question to encourage the student's thinking.
3. Remains concise (around 3-4 sentences).

Response:"""
        response = self.llm.invoke(prompt)
        return response.content.strip()
