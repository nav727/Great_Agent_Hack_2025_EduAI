# aegis/__init__.py
"""
AEGIS X — Multi-Agent Governance Layer

This module provides:
- Guardian agent (safety & policy enforcement)
- Attacker agent (red-team simulation)
- Observer agent (logging & explainability)
- Wrapper for supervising and testing NOVA

AEGIS sits on top of agentic systems to ensure trustworthy and robust outputs.
"""
