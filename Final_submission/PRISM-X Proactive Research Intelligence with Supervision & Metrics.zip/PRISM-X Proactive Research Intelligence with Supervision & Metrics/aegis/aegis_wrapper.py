# aegis/wrapper.py
from aegis.guardian import Guardian
from aegis.attacker import Attacker
from aegis.observer import Observer
from nova.idea_generator import IdeaGenerator
from nova.intent_classifier import IntentClassifier
from nova.citation_ranker import CitationRanker
from nova.answer_agent import AnswerAgent
from nova.valyu_fetcher import ValyuResearchFetcher
from typing import List, Dict
from datetime import datetime

class AegisWrapper:
    def __init__(self, valyu_api_key: str):
        self.guardian = Guardian()
        self.attacker = Attacker()
        self.observer = Observer()
        self.classifier = IntentClassifier()
        self.generator = IdeaGenerator()
        self.ranker = CitationRanker()
        self.tutor = AnswerAgent()
        self.valyu = ValyuResearchFetcher(valyu_api_key)

    def check_query(self, query: str):
        intent = self.classifier.classify(query)
        guardian_eval = self.guardian.evaluate(user_input=query)
        self.observer.log_query(query, guardian_eval)
        return {
            "intent": intent,
            "guardian": guardian_eval
        }

    def check_idea(self, idea: Dict):
        guardian_eval = self.guardian.evaluate(user_input="", idea=idea)
        self.observer.log_idea(idea, guardian_eval)
        return guardian_eval

    def run_attack(self, use_research: bool = False):
        attack = self.attacker.generate(use_research=use_research)
        intent = self.classifier.classify(attack['text'])
        guardian_eval = self.guardian.evaluate(user_input=attack['text'])
        if guardian_eval['allowed']:
            self.guardian.learn_attack(attack['text'])
        self.observer.log_attack(attack, guardian_eval)
        return {
            "attack": attack,
            "intent": intent,
            "guardian": guardian_eval
        }

    def bootstrap_knowledge(self, topic: str):
        print(f"\n🧠 Bootstrapping from topic: {topic}")
        valyu_snippets = self.valyu.fetch_related_snippets(topic)
        if not valyu_snippets:
            print("⚠️  No relevant Valyu papers found. Aborting bootstrap.")
            return False

        ideas = self.generator.generate(valyu_snippets, buzzwords=[topic])
        defenses = [i for i in ideas if i.get("type") == "defense"]
        attacks = [i for i in ideas if i.get("type") == "attack"]
        self.guardian.load_defenses(defenses)
        self.attacker.load_attacks(attacks)
        self.observer.log({
            "event": "bootstrap",
            "topic": topic,
            "ideas": ideas,
            "loaded_attacks": len(attacks),
            "loaded_defenses": len(defenses),
        })
        return True

    def handle_user_idea_request(self, topic: str, buzzwords: List[str], summaries: List[str]):
        print("\n🎯 Handling user research idea request")
        ideas = self.generator.generate(summaries, buzzwords)
        filtered = [i for i in ideas if self.check_idea(i)['allowed']]
        return filtered

    def tutor_response(self, query: str):
        intent = self.classifier.classify(query)
        guardian_eval = self.guardian.evaluate(query)
        if guardian_eval['allowed']:
            response = self.tutor.answer(query, intent.get("subject", "general"))
        else:
            response = "I'm sorry, I cannot help with that request."
        self.observer.log({
            "event": "tutor_response",
            "query": query,
            "intent": intent,
            "guardian_eval": guardian_eval,
            "response": response
        })
        return response