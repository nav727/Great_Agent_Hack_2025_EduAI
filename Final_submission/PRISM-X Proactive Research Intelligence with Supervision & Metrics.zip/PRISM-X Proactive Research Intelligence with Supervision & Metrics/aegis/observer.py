from datetime import datetime
import json
from typing import Dict

class Observer:
    def __init__(self, logfile: str = "logs/aegis_log.jsonl"):
        self.logfile = logfile

    def log(self, event: Dict):
        event["timestamp"] = datetime.utcnow().isoformat()
        with open(self.logfile, "a") as f:
            f.write(json.dumps(event) + "\n")

    def log_idea(self, idea: Dict, result: Dict):
        self.log({
            "event": "idea_check",
            "idea": idea,
            "guardian": result
        })

    def log_query(self, query: str, result: Dict):
        self.log({
            "event": "query_check",
            "query": query,
            "guardian": result
        })

    def log_attack(self, attack: Dict, result: Dict):
        self.log({
            "event": "attack_attempt",
            "attack": attack,
            "guardian": result
        })