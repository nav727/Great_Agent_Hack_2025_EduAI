from holistic_ai_bedrock import get_chat_model
from typing import List, Dict, Optional
from datetime import datetime

class Guardian:
    def __init__(self):
        self.llm = get_chat_model()
        self.research_defenses: List[Dict] = []
        self.attack_patterns: List[str] = []
        self.allowed = 0
        self.blocked = 0

    def load_defenses(self, defenses: List[Dict]):
        self.research_defenses.extend(defenses)

    def evaluate(self, user_input: str, idea: Optional[Dict] = None) -> Dict:
        defenses = "\n".join([
            f"- {d.get('name')}: {d.get('mechanism')[:80]}" for d in self.research_defenses[:3]
        ]) or "None"

        prompt = f"""
You are the Guardian agent in an agent governance system.
Check the following:
USER INPUT: {user_input}
IDEA: {idea.get('raw') if idea else 'N/A'}

KNOWN DEFENSES:
{defenses}

Make a decision.
Respond with:
DECISION: ALLOW/BLOCK/REVIEW
REASON: <short reason>
"""
        response = self.llm.invoke(prompt)
        lines = response.content.strip().splitlines()
        decision = next((line.split(":", 1)[-1].strip().upper() for line in lines if line.startswith("DECISION:")), "REVIEW")
        reason = next((line.split(":", 1)[-1].strip() for line in lines if line.startswith("REASON:")), "Could not parse response.")
        allowed = decision == "ALLOW"

        self.allowed += int(allowed)
        self.blocked += int(not allowed)

        return {
            "allowed": allowed,
            "decision": decision,
            "reason": reason,
            "timestamp": datetime.utcnow().isoformat(),
            "defenses_loaded": len(self.research_defenses)
        }

    def learn_attack(self, text: str):
        self.attack_patterns.append(text)